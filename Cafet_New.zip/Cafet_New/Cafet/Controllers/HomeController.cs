﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.Configuration;
using System.Xml;
using System.IO;
using System.Data;
using System.Collections;

using Cafet.Models;

namespace Cafet.Controllers
{
    public class HomeController : Controller
    {
        static SortedList currentList = null;
        static SortedList pastList = null;

        int currentOccupancy;
        int pastOccupancy;
        static int totalOccupancy = int.Parse(ConfigurationSettings.AppSettings["TotalOccupancy"].ToString());
        static int nDaysBack;
        XmlDocument xmlDoc;

        public HomeController()
        {
            currentOccupancy = 0;
            pastOccupancy = 0;
            if (!int.TryParse(ConfigurationSettings.AppSettings["TotalOccupancy"].ToString(), out totalOccupancy))
            {
                totalOccupancy = 0;
            }

            if (!int.TryParse(ConfigurationSettings.AppSettings["DaysBack"].ToString(), out nDaysBack))
            {
                nDaysBack = 0;
            }

            currentList = new SortedList();
            pastList = new SortedList();
            xmlDoc = null;
        }

        public ActionResult Index()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";
            string strFolder = ConfigurationSettings.AppSettings["Images"] + "\\" + DateTime.Now.ToString("ddMMyyyy") + "\\";
            ViewBag.FoodImage1 = strFolder + ConfigurationSettings.AppSettings["FoodImage1"];
            ViewBag.ExceriseImage1 = strFolder + ConfigurationSettings.AppSettings["ExceriseImage1"];

            ViewBag.FoodImage2 = strFolder + ConfigurationSettings.AppSettings["FoodImage2"];
            ViewBag.ExceriseImage2 = strFolder + ConfigurationSettings.AppSettings["ExceriseImage2"];

            ViewBag.FoodImage3 = strFolder + ConfigurationSettings.AppSettings["FoodImage3"];
            ViewBag.ExceriseImage3 = strFolder + ConfigurationSettings.AppSettings["ExceriseImage3"];

            return View("index");
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [HttpGet]
        public JsonResult GetData()
        {
            List<StatusInfo> objStatusInfoList = ReadXmlData();
            return Json(objStatusInfoList, JsonRequestBehavior.AllowGet);
        }

        List<StatusInfo> ReadXmlData()
        {
            List<StatusInfo> objStatusInfoList = null;
            string dataFile = Server.MapPath("~/") + ConfigurationSettings.AppSettings["DataFile"];
            MemoryStream objMemoryStream = new MemoryStream();
            using (Stream input = System.IO.File.OpenRead(dataFile))
            {
                input.CopyTo(objMemoryStream);
            }
            objMemoryStream.Position = 0;

            StreamReader sr = new StreamReader(objMemoryStream);
            string xmlData = sr.ReadToEnd();
            if (xmlDoc == null)
            {
                xmlDoc = new XmlDocument();
            }
            xmlDoc.LoadXml(xmlData);

            string currentDate = "12/10/2017";// DateTime.Now.ToString("MM/dd/yyyy");
            string pastDate = "09/10/2017"; //DateTime.Now.AddDays(-nDaysBack).ToString("MM/dd/yyyy");

            FillDataForSelectedDate(currentDate, currentList);
            FillDataForSelectedDate(pastDate, pastList);

            if (objStatusInfoList == null)
            {
                objStatusInfoList = new List<StatusInfo>();
            }
            else
            {
                objStatusInfoList.Clear();
            }

            FillStatusInfo(objStatusInfoList);

            return objStatusInfoList;
        }

        void FillStatusInfo(List<StatusInfo> objStatusInfoList)
        {
            for(int nIndex =0; nIndex < currentList.Count; nIndex++)
            {
                StatusInfo objStatusInfo = new StatusInfo((string)currentList.GetKey(nIndex), (int)currentList.GetByIndex(nIndex), (int)pastList.GetByIndex(nIndex));
                objStatusInfoList.Add(objStatusInfo);
            }
        }

        void FillDataForSelectedDate(string date, SortedList list)
        {
            if (list.Count > 0)
            {
                currentOccupancy = (int)list[list.Count - 1];
            }
            else
            {
                currentOccupancy = 0;
            }

            XmlNodeList currentDataNodeList = xmlDoc.SelectNodes("//Date[@value = '" + date + "']");
            string strKey;
            if (currentDataNodeList.Count > 0)
            {
                foreach (XmlNode xmlNode in currentDataNodeList[0].ChildNodes)
                {
                    strKey = xmlNode.Name.Trim('T').Insert(2, ":");
                    if (list.ContainsKey(strKey))
                    {
                        continue;
                    }
                    
                    currentOccupancy = ((currentOccupancy + int.Parse(((XmlElement)xmlNode).GetAttribute("In")) -
                                        int.Parse(((XmlElement)xmlNode).GetAttribute("Out"))) * 100) / totalOccupancy;
                    if (currentOccupancy < 0)
                    {
                        currentOccupancy = 0;
                    }

                    list.Add(strKey, currentOccupancy);
                }
            }
        }
    }
}
