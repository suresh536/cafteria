﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

using System.Configuration;
using System.Xml;
using System.IO;
using System.Data;
using System.Collections;

using Cafet.Models;

namespace Cafet.Controllers
{
    public class HomeController : Controller
    {
        static SortedList currentList = null;
        static SortedList pastList = null;

        static int currentOccupancy;
        static int pastOccupancy;
        static int totalOccupancy = int.Parse(ConfigurationSettings.AppSettings["TotalOccupancy"].ToString());
        static int nDaysBack;

            public HomeController()
            {
                currentOccupancy= 0;
                pastOccupancy = 0;
                if(!int.TryParse(ConfigurationSettings.AppSettings["TotalOccupancy"].ToString(), out totalOccupancy))
                {
                    totalOccupancy = 0;
                }
                
                if (!int.TryParse(ConfigurationSettings.AppSettings["DaysBack"].ToString(), out nDaysBack))
                {
                    nDaysBack = 0;
                }

                currentList = new SortedList();
                pastList = new SortedList();
            }
        public ActionResult Index()
        {
            ViewBag.Message = "Modify this template to jump-start your ASP.NET MVC application.";

            ViewBag.FoodImage1 = ConfigurationSettings.AppSettings["FoodImage1"];
            ViewBag.ExceriseImage1 = ConfigurationSettings.AppSettings["ExceriseImage1"];

            ViewBag.FoodImage2 = ConfigurationSettings.AppSettings["FoodImage2"];
            ViewBag.ExceriseImage2 = ConfigurationSettings.AppSettings["ExceriseImage2"];
            
            ViewBag.FoodImage3 = ConfigurationSettings.AppSettings["FoodImage3"];
            ViewBag.ExceriseImage3 = ConfigurationSettings.AppSettings["ExceriseImage3"];

            return View("index");
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        [HttpGet]
        public JsonResult GetData()
        {
            List<StatusInfo> objStatusInfoList = ReadXmlData();
            return Json(objStatusInfoList, JsonRequestBehavior.AllowGet);
        }

        List<StatusInfo> ReadXmlData()
        {
            List<StatusInfo> objStatusInfoList= null;
            string dataFile = Server.MapPath("~/") + ConfigurationSettings.AppSettings["DataFile"];
            MemoryStream objMemoryStream = new MemoryStream();
            using(Stream input = System.IO.File.OpenRead(dataFile))
            {
                input.CopyTo(objMemoryStream);
            }
            objMemoryStream.Position = 0;

            StreamReader sr = new StreamReader(objMemoryStream);
            string xmlData = sr.ReadToEnd();
            XmlDocument xmlDoc = new XmlDocument();
            xmlDoc.LoadXml(xmlData);

            string currentDate = "10/10/2017";// DateTime.Now.ToString("MM/dd/yyyy");
            string pastDate = DateTime.Now.AddDays(-nDaysBack).ToString("MM/dd/yyyy");

            XmlNodeList currentDataNodeList = xmlDoc.SelectNodes("//Date[@value = '" + currentDate + "']");// 10/10/2017']");
            if (objStatusInfoList == null)
            {
                objStatusInfoList = new List<StatusInfo>();
            }
            else
            {
                objStatusInfoList.Clear();
            }
            if (currentDataNodeList.Count > 0)
            {
                foreach (XmlNode xmlNode in currentDataNodeList[0].ChildNodes)
                {
                    currentList.Add(xmlNode.Name.Trim('T').Insert(2, ":"), currentOccupancy);
                    currentOccupancy = ((currentOccupancy + int.Parse(((XmlElement)xmlNode).GetAttribute("In")) -
                                        int.Parse(((XmlElement)xmlNode).GetAttribute("Out"))) * 100) / totalOccupancy;
                    if (currentOccupancy < 0)
                    {
                        currentOccupancy = 0;
                    }

                    StatusInfo objStatusInfo = new StatusInfo(xmlNode.Name.Trim('T').Insert(2, ":"), currentOccupancy, -20);
                    objStatusInfoList.Add(objStatusInfo);
                }
            }

            foreach (XmlNode xmlNode in currentDataNodeList[0].ChildNodes)
            {
                currentOccupancy = ((currentOccupancy + int.Parse(((XmlElement)xmlNode).GetAttribute("In")) -
                                    int.Parse(((XmlElement)xmlNode).GetAttribute("Out"))) * 100) / totalOccupancy;
                if (currentOccupancy < 0)
                {
                    currentOccupancy = 0;
                }

                StatusInfo objStatusInfo = new StatusInfo(xmlNode.Name.Trim('T').Insert(2, ":"), currentOccupancy, -20);
                objStatusInfoList.Add(objStatusInfo);
            }
            return objStatusInfoList;
        }
    }
}
