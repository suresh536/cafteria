$(document).ready(function () {
    google.charts.load("visualization", "1", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChart);
});

function drawChart() {
    //debugger;
    $.ajax({
        url: 'Home/GetData',
        data: [],
        datatype: 'json',
        type: 'get',
        success: function (response) {
            var data = new google.visualization.DataTable();
            data.addColumn('string', 'Time Period');
            data.addColumn('number', 'Current');
            data.addColumn('number', 'Past');
            //data.addRows(response.length);
            for (var i = 0; i < response.length; i++) {
                    data.addRow([response[i].TimePeriod, response[i].Current, response[i].Past]);
                
                //data.setValue(i, 0, response[i].TimePeriod);
                //if (response[i].Current > -1) {
                //    data.setValue(i, 1, response[i].Current);
                //}
                //if (response[i].Past < -1) {
                // //   data.setValue(i, 2, null);
                //}
            }

            var options = {
                isStaked: false,
                legend: 'none',
                line: { groupWidth: '85%' },
                colors: ['red', 'yellow'],
                interpolateNulls: true,
                //scaleType: mirrorLog,
                tooltip: { isHtml: true },
                hAxis: {
                    title: 'Time Period',
                    gridlines: {
                        color: 'trasparent'
                    },
                    ticks: [0, 25, 50, 75]
                },
                vAxis: {
                    title: 'Occupancy',
                    minValue: 0,
                    maxValue: 100,
                    format: '#\'%\''
                }
            };
            
            var chart = new google.visualization.LineChart(document.getElementById('Hall2'));
            chart.draw(data, options);

            chart = new google.visualization.LineChart(document.getElementById('Hall3'));
            chart.draw(data, options);
        }
    });

    setInterval(function () {
        drawChart();
    }, 50000);

    function setTooltipContent(data, e) {
        if (e.row != null && e.column == 1) {
            var val = Math.abs(data.getValue(e.row, 1));
            var tooltipTextLabel = $(".google-visualization-tooltip-item-list li:eq(1) span:eq(1)");
            tooltipTextLabel.text(val.tos());
        }
    }
}