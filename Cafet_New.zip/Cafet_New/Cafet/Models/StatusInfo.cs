﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cafet.Models
{
    public class StatusInfo
    {
        public string TimePeriod { get; set; }
        public int Current { get; set; }
        public int Past { get; set; }

        public StatusInfo(string timePeriod, int occ1, int occ2)
        {
            TimePeriod = timePeriod;
            Current = occ1;
            Past = occ2;
        }
    }
}