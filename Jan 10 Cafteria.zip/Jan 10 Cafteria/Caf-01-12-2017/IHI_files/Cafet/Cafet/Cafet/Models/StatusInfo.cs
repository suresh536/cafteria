﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Cafet.Models
{
    public class StatusInfo
    {
        public decimal TimePeriod { get; set; }
        public int NoofPersons { get; set; }
        public string Tooltip { get; set; }

        public StatusInfo(decimal timePeriod, int noofPersons, string tooltip)
        {
            TimePeriod = timePeriod;
            NoofPersons = noofPersons;
            Tooltip = tooltip;
        }
    }
}