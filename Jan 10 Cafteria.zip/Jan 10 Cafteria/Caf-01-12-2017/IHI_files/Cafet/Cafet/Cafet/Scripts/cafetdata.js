$(document).ready(function () {
    google.charts.load("visualization", "1", { packages: ["corechart"] });
    google.charts.setOnLoadCallback(drawChart);
});

function drawChart() {
    //debugger;
    $.ajax({
        url: 'Home/GetData',
        data: [],
        datatype: 'json',
        type: 'get',
        success: function (response) {
            var current = new google.visualization.DataTable();
            current.addColumn('number', 'Time Period');
            current.addColumn('number', 'Current');
            current.addColumn({ type: 'string', role: 'tooltip' });
            current.addColumn({ type: 'string', role: 'annotation' });

            for (var i = 0; i < response.Current.length; i++) {
                current.addRow([response.Current[i].TimePeriod, response.Current[i].NoofPersons, response.Current[i].Tooltip.split(":")[0] + ' PM      Count(%):' + response.Current[i].NoofPersons, response.Current[i].Tooltip.split(":")[1]]);
            }

            var past = new google.visualization.DataTable();
            past.addColumn('number', 'Time Period');
            past.addColumn('number', 'Past');
            past.addColumn({ type: 'string', role: 'tooltip' });
            past.addColumn({ type: 'string', role: 'annotation' });

            for (var i = 0; i < response.Past.length; i++) {

                past.addRow([response.Past[i].TimePeriod, response.Past[i].NoofPersons, response.Past[i].Tooltip.split(":")[0] + ' PM      Count(%):' + response.Past[i].NoofPersons, response.Past[i].Tooltip.split(":")[1]]);
            }

            var joindata = google.visualization.data.join(current, past, 'full', [[0, 0]], [1], [1]);
            var options = {
                colors: ['ForestGreen', 'blue'],
                tooltip: { isHtml: true },
                displayAnnotations: true,
                hAxis: {
                    title: 'Time Period',
                    backgroundcolor: '#f1f8e9',
                    ticks: [{ v: 14.00, f: '14:00' }, { v: 14.25, f: '14:15' }, { v: 14.50, f: '14:30' }, { v: 14.75, f: '14:45' }, { v: 15.00, f: '15:00' }, { v: 15.25, f: '15:15' }, { v: 15.50, f: '15:30' }, { v: 15.75, f: '15:45' }, { v: 16.00, f: '16:00' }, { v: 16.25, f: '16:15' }, { v: 16.50, f: '16:30' }, { v: 16.75, f: '16:45' }, { v: 17.00, f: '17:00' }]

                },
                vAxis: {
                    title: 'Occupancy',
                    minValue: 0,
                    maxValue: 100,
                    format: '#\'%\''
                }
            };

            var chart = new google.visualization.LineChart(document.getElementById('Hall2'));
            chart.draw(joindata, options);

            //chart = new google.visualization.LineChart(document.getElementById('Hall3'));
            //chart.draw(data, options);
        }
    });

    setInterval(function () {
        drawChart();
    }, 100000);

    function setTooltipContent(data, e) {
        if (e.row != null && e.column == 1) {
            var val = Math.abs(data.getValue(e.row, 1));
            var tooltipTextLabel = $(".google-visualization-tooltip-item-list li:eq(1) span:eq(1)");
            tooltipTextLabel.text(val.tos());
        }
    }
}