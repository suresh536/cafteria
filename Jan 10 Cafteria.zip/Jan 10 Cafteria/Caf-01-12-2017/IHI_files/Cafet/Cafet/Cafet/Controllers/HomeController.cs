﻿using Cafet.Models;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.IO;
using System.Linq;
using System.Web.Mvc;
using System.Xml;
using System.Xml.Linq;

namespace Cafet.Controllers
{
    public class HomeController : Controller
    {
        static SortedList currentList = null;
        static SortedList pastList = null;
        static SortedList tootlTiplist = null;
        static SortedList pasttootlTiplist = null;
        static List<cafterialdetailsexist> cafterialdetailsexists = new List<cafterialdetailsexist>();

        int currentOccupancy;
        int pastOccupancy;
        static int totalOccupancy = int.Parse(ConfigurationSettings.AppSettings["TotalOccupancy"].ToString());
        static int nDaysBack;
        XmlDocument xmlDoc;

        public HomeController()
        {
            string directoryPath = System.Web.HttpContext.Current.Server.MapPath(string.Format("~/{0}/{1}/", "Images", DateTime.Now.ToString("ddMMyyyy")));
            if (!Directory.Exists(directoryPath))
            {
                Directory.CreateDirectory(directoryPath);
                string[] files = System.IO.Directory.GetFiles(System.Web.HttpContext.Current.Server.MapPath("~/Images/CommonImages/"));
                foreach (var item in files)
                {
                    string filename = System.IO.Path.GetFileName(item);
                    string destfile = System.IO.Path.Combine(directoryPath, filename);
                    System.IO.File.Copy(item, destfile, true);
                }
            }
            currentOccupancy = 0;
            pastOccupancy = 0;
            if (!int.TryParse(ConfigurationSettings.AppSettings["TotalOccupancy"].ToString(), out totalOccupancy))
            {
                totalOccupancy = 0;
            }

            if (!int.TryParse(ConfigurationSettings.AppSettings["DaysBack"].ToString(), out nDaysBack))
            {
                nDaysBack = 0;
            }

            currentList = new SortedList();
            pastList = new SortedList();
            tootlTiplist = new SortedList();
            pasttootlTiplist = new SortedList();

            xmlDoc = null;

            DirectoryInfo d = new DirectoryInfo(@"E:\IOT-Seats\Files\FInal_Files");//Assuming Test is your Folder
            List<cafterialdetails> objbasedetails = new List<cafterialdetails>();
            d.Refresh();
            FileInfo[] Files = d.GetFiles("*.xml");

            foreach (var item in Files)
            {
                item.Refresh();
                XDocument doc;
                using (var reader = XmlReader.Create(item.FullName))
                {
                    doc = XDocument.Load(reader);
                }
                //XDocument doc = XDocument.Load(item.FullName);
                var selecteddata = (from r in doc.Descendants("Date")
                                    select r);
                XElement a = selecteddata.ElementAt(0);

                cafterialdetails objdetails = new cafterialdetails(); //OUT - CountOUT: 
                objdetails.TimePeriod = a.LastAttribute.ToString().Replace("Todays Time:", "").Replace("Time=", "").Replace("\"", "").Substring(0, 5);
                objdetails.Past = int.Parse(a.FirstAttribute.NextAttribute.ToString().Replace("OUT-CountOUT:", "").Replace("CountOut=", "").Replace("\"", ""));
                objdetails.date = a.FirstAttribute.NextAttribute.NextAttribute.ToString().Replace("Todays Date:", "").Replace("Date=", "").Replace("\"", "");
                objdetails.Current = int.Parse(a.FirstAttribute.ToString().Replace("IN-CountIN:", "").Replace("CountIn=", "").Replace("\"", ""));


                objbasedetails.Add(objdetails);

            }


            string dataFile = System.Web.HttpContext.Current.Server.MapPath("~/") + ConfigurationSettings.AppSettings["DataFile"];

            FileStream fs = new FileStream(dataFile, FileMode.Open, FileAccess.Read,
                               FileShare.ReadWrite);
            xmlDoc = new XmlDocument();
            xmlDoc.Load(fs);

            XmlNodeList xmlnode = xmlDoc.GetElementsByTagName("Date");
            int count = xmlnode.Count;
            // New XML Element Created

            XmlElement newcatalogentry = null;
            var value = xmlnode[count - 1].Attributes[0].Value;
            var objStatusInfoList = objbasedetails.GroupBy(f => new { f.date }).Select(group => new cafterialdetails { TimePeriod = group.Max(a => a.TimePeriod), Current = group.Sum(f => f.Current), Past = group.Sum(f => f.Past) }).ToList();

            if (cafterialdetailsexists.Where(a => a.TimePeriod == objStatusInfoList[0].TimePeriod).Count() == 0)
            {

                if (value.ToString() != DateTime.Now.Date.ToShortDateString())
                {
                    newcatalogentry = xmlDoc.CreateElement("Date");
                    // New Attribute Created
                    XmlAttribute newcatalogattr = xmlDoc.CreateAttribute("value");

                    // Value given for the new attribute
                    newcatalogattr.Value = DateTime.Now.Date.ToShortDateString();

                    // Attach the attribute to the XML element
                    newcatalogentry.SetAttributeNode(newcatalogattr);

                    // First Element - Book - Created
                    foreach (var item in objStatusInfoList)
                    {
                        XmlElement firstelement = xmlDoc.CreateElement("T" + item.TimePeriod.Replace(":", ""));
                        XmlAttribute xKey = xmlDoc.CreateAttribute("In");
                        XmlAttribute xValue = xmlDoc.CreateAttribute("Out");
                        xKey.Value = item.Current.ToString();
                        xValue.Value = item.Past.ToString();
                        firstelement.SetAttributeNode(xKey);
                        firstelement.SetAttributeNode(xValue);
                        // Append the newly created element as a child element
                        newcatalogentry.AppendChild(firstelement);

                        // New XML element inserted into the document
                        xmlDoc.DocumentElement.InsertAfter(newcatalogentry,
                                                           xmlDoc.DocumentElement.LastChild);
                        cafterialdetailsexists.Add(new cafterialdetailsexist { TimePeriod = item.TimePeriod });
                    }

                }

                else
                {
                    foreach (var item in objStatusInfoList)
                    {
                        XmlNodeList nodes = xmlDoc.SelectNodes("//Date");
                        XmlElement firstelement = xmlDoc.CreateElement("T" + item.TimePeriod.Replace(":", ""));
                        XmlAttribute xKey = xmlDoc.CreateAttribute("In");
                        XmlAttribute xValue = xmlDoc.CreateAttribute("Out");
                        xKey.Value = item.Current.ToString();
                        xValue.Value = item.Past.ToString();
                        firstelement.SetAttributeNode(xKey);
                        firstelement.SetAttributeNode(xValue);
                        // Append the newly created element as a child element
                        nodes[count - 1].AppendChild(firstelement);

                        // New XML element inserted into the document
                        xmlDoc.DocumentElement.InsertAfter(nodes[count - 1],
                                                           xmlDoc.DocumentElement.LastChild);
                        cafterialdetailsexists.Add(new cafterialdetailsexist { TimePeriod = item.TimePeriod, Current = item.Current, Past = item.Past });
                    }
                }

                SessionManager.CafteriaDetails = objStatusInfoList.ToList();

                // An instance of FileStream class created
                // The first parameter is the path to the XML file - Catalog.xml

                FileStream fsxml = new FileStream(dataFile, FileMode.Truncate,
                                                  FileAccess.Write,
                                                  FileShare.ReadWrite);

                // XML Document Saved
                xmlDoc.Save(fsxml);
            }
        }

        public ActionResult Index()
        {
            ViewBag.day = DateTime.Now.DayOfWeek;
            string strFolder = ConfigurationSettings.AppSettings["Images"] + "\\" + DateTime.Now.ToString("ddMMyyyy") + "\\";
            ViewBag.FoodImage1 = strFolder + ConfigurationSettings.AppSettings["FoodImage1"];
            ViewBag.ExceriseImage1 = strFolder + ConfigurationSettings.AppSettings["ExceriseImage1"];
            ViewBag.FoodImage2 = strFolder + ConfigurationSettings.AppSettings["FoodImage2"];
            ViewBag.ExceriseImage2 = strFolder + ConfigurationSettings.AppSettings["ExceriseImage2"];
            ViewBag.FoodImage3 = strFolder + ConfigurationSettings.AppSettings["FoodImage3"];
            ViewBag.ExceriseImage3 = strFolder + ConfigurationSettings.AppSettings["ExceriseImage3"];

            return View("index");
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your app description page.";

            return View();
        }

        [HttpGet]
        public JsonResult GetData()
        {
            //List<StatusInfo> objStatusInfoList = ReadXmlData();
            List<StatusInfo> objStatusInfoListPast = null;
            List<StatusInfo> objStatusInfoListCurrent = null;
            string dataFile = Server.MapPath("~/") + ConfigurationSettings.AppSettings["DataFile"];
            string currentDate = DateTime.Now.Date.ToShortDateString();
            string pastDate = DateTime.Now.AddDays(-1).ToShortDateString();

            FillDataForSelectedDate(currentDate, currentList, tootlTiplist);
            FillDataForSelectedDate(pastDate, pastList, pasttootlTiplist);

            if (objStatusInfoListPast == null)
            {
                objStatusInfoListPast = new List<StatusInfo>();
            }
            else
            {
                objStatusInfoListPast.Clear();
            }

            if (objStatusInfoListCurrent == null)
            {
                objStatusInfoListCurrent = new List<StatusInfo>();
            }
            else
            {
                objStatusInfoListCurrent.Clear();
            }
            for (int nIndex = 0; nIndex < currentList.Count; nIndex++)
            {

                StatusInfo objStatusInfo = new StatusInfo((decimal)currentList.GetKey(nIndex), (int)currentList.GetByIndex(nIndex), (string)tootlTiplist.GetByIndex(nIndex));
                objStatusInfoListCurrent.Add(objStatusInfo);
            }

            for (int nIndex = 0; nIndex < pastList.Count; nIndex++)
            {

                StatusInfo objStatusInfo = new StatusInfo((decimal)pastList.GetKey(nIndex), (int)pastList.GetByIndex(nIndex), (string)pasttootlTiplist.GetByIndex(nIndex));
                objStatusInfoListPast.Add(objStatusInfo);
            }
            return Json(new {Current= objStatusInfoListCurrent,Past= objStatusInfoListPast }, JsonRequestBehavior.AllowGet);
        }

        List<StatusInfo> ReadXmlData()
        {
            try
            {
                List<StatusInfo> objStatusInfoList = null;
                string dataFile = Server.MapPath("~/") + ConfigurationSettings.AppSettings["DataFile"];
                string currentDate = DateTime.Now.Date.ToShortDateString();
                string pastDate = DateTime.Now.AddDays(-1).ToShortDateString();

                FillDataForSelectedDate(currentDate, currentList, tootlTiplist);
                FillDataForSelectedDate(pastDate, pastList, pasttootlTiplist);

                if (objStatusInfoList == null)
                {
                    objStatusInfoList = new List<StatusInfo>();
                }
                else
                {
                    objStatusInfoList.Clear();
                }

                //FillStatusInfo(objStatusInfoList);
                return objStatusInfoList;
            }
            catch (Exception ex)
            {
                throw ex;

            }


        }


        //void FillStatusInfo(List<StatusInfo> objStatusInfoList)
        //{
        //    try
        //    {
        //        for (int nIndex = 0; nIndex < currentList.Count; nIndex++)
        //        {

        //                StatusInfo objStatusInfo = new StatusInfo((decimal)currentList.GetKey(nIndex), (int)currentList.GetByIndex(nIndex), (int)pastList.GetByIndex(nIndex), (string)tootlTiplist.GetByIndex(nIndex), (string)pasttootlTiplist.GetByIndex(nIndex));
        //                objStatusInfoList.Add(objStatusInfo);



        //        }



        //    }
        //    catch (Exception ex)
        //    {
        //        throw ex;
        //    }
        //}

        void FillDataForSelectedDate(string date, SortedList list, SortedList tootlTiplist)
        {
            try
            {
                var currentOccupancyPercnt = 0;
                var pastOccupancyPercnt = 0;
                if (date == DateTime.Now.ToShortDateString())
                {
                    if (list.Count > 0)
                    {
                        currentOccupancy = (int)list[list.Count - 1];
                    }
                    else
                    {
                        currentOccupancy = 0;
                    }
                }
                else
                {
                    if (list.Count > 0)
                    {
                        pastOccupancy = (int)list[list.Count - 1];
                    }
                    else
                    {
                        pastOccupancy = 0;
                    }
                }
                XmlNodeList currentDataNodeList = xmlDoc.SelectNodes("//Date[@value = '" + date + "']");
                decimal strKey = 0.00m;
                if (currentDataNodeList.Count > 0)
                {
                    foreach (XmlNode xmlNode in currentDataNodeList[0].ChildNodes)
                    {
                        var timecomponent = xmlNode.Name.Trim('T').Insert(2, ".");
                        var timecomponent1 = Convert.ToDecimal(xmlNode.Name.Trim('T').Insert(2, "."));
                        var mincomponent = float.Parse(timecomponent.Split('.')[1]) / 60;
                        var strTime = (timecomponent.Split('.')[0] + mincomponent.ToString().Substring(1));
                        strKey = strTime.Length > 5 ? Convert.ToDecimal(strTime.Substring(0, 5)) : Convert.ToDecimal(strTime);
                        if (list.ContainsKey(strKey))
                        {
                            continue;
                        }

                        if (tootlTiplist.ContainsKey(strKey))
                        {
                            continue;
                        }

                        if (pasttootlTiplist.ContainsKey(strKey))
                        {
                            continue;
                        }

                        if (date == DateTime.Now.ToShortDateString())
                        {
                            currentOccupancy = (currentOccupancy + int.Parse(((XmlElement)xmlNode).GetAttribute("In")) -
                                            int.Parse(((XmlElement)xmlNode).GetAttribute("Out")));
                            currentOccupancyPercnt = (currentOccupancy * 100) / totalOccupancy;

                            if (currentOccupancyPercnt < 0)
                            {
                                currentOccupancyPercnt = 0;
                            }
                        }
                        else
                        {
                            pastOccupancy = (pastOccupancy + int.Parse(((XmlElement)xmlNode).GetAttribute("In")) -
                                                                      int.Parse(((XmlElement)xmlNode).GetAttribute("Out")));
                            pastOccupancyPercnt = (pastOccupancy * 100) / totalOccupancy;

                            if (pastOccupancyPercnt < 0)
                            {
                                pastOccupancyPercnt = 0;
                            }
                        }
                        if (currentOccupancyPercnt != null && timecomponent != null)
                        {
                            if (date == DateTime.Now.ToShortDateString())
                            {
                                var a = currentOccupancyPercnt > 100 ? currentOccupancyPercnt / 2 : currentOccupancyPercnt;
                                a = a > 100 ? a / 2 : a;
                                a = a > 100 ? a / 2 : a;
                                list.Add(strKey, a);
                                tootlTiplist.Add(strKey, timecomponent1 + ":" + currentOccupancy);
                            }
                            else
                            {
                                if (pastOccupancyPercnt != null && timecomponent != null)
                                {
                                    var a = pastOccupancyPercnt > 100 ? pastOccupancyPercnt / 2 : pastOccupancyPercnt;
                                    a = a > 100 ? a / 2 : a;
                                    a = a > 100 ? a / 2 : a;
                                    list.Add(strKey, a);
                                    pasttootlTiplist.Add(strKey, timecomponent1 + ":" + pastOccupancy);
                                }
                            }
                        }



                    }
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }

        }

        public class cafterialdetails
        {
            public string date { get; set; }
            public string TimePeriod { get; set; }
            public int Current { get; set; }
            public int Past { get; set; }
        }

        public class cafterialdetailsexist
        {
            public string date { get; set; }
            public string TimePeriod { get; set; }
            public int Current { get; set; }
            public int Past { get; set; }
        }

        public class SessionManager
        {
            public static List<cafterialdetails> CafteriaDetails
            {
                get
                {
                    if (System.Web.HttpContext.Current.Session["cafterialdetails"] != null)
                        return System.Web.HttpContext.Current.Session["cafterialdetails"] as List<cafterialdetails>;
                    else

                        return new List<cafterialdetails>();


                }

                set { System.Web.HttpContext.Current.Session["cafterialdetails"] = value; }
            }


        }
    }
}
